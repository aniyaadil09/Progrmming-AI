from flask import Flask, render_template, request
from utils.analyzer import analyze_resume_text
from utils.jobs import recommend_jobs

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    resume_text = request.form["resume"]
    job_desc = request.form["jobdesc"]

    result = analyze_resume_text(resume_text, job_desc)
    jobs = recommend_jobs(resume_text)

    return render_template("result.html", result=result, jobs=jobs)

if __name__ == "__main__":
    app.run(debug=True)