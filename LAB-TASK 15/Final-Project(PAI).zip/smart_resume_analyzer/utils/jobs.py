def recommend_jobs(resume_text):
    text = resume_text.lower()

    jobs = []

    if "python" in text and "sql" in text:
        jobs.append("Data Analyst")

    if "python" in text and "machine learning" in text:
        jobs.append("Machine Learning Engineer")

    if "flask" in text or "django" in text:
        jobs.append("Backend Developer")

    if "html" in text and "css" in text and "javascript" in text:
        jobs.append("Frontend Developer")

    if "react" in text:
        jobs.append("Full Stack Developer")

    if "power bi" in text or "excel" in text:
        jobs.append("Business Intelligence Analyst")

    if not jobs:
        jobs.append("General Software Engineer")

    return jobs