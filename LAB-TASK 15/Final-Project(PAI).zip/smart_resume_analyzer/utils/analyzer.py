import re
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

COMMON_SKILLS = [
    "python","sql","java","c++","flask","django","html","css","javascript",
    "react","machine learning","nlp","excel","power bi","communication",
    "teamwork","git","data analysis","aws","api"
]

def clean_text(text):
    return re.sub(r'[^a-zA-Z0-9\s]', '', text.lower())

def extract_skills(text):
    text = text.lower()
    found = []
    for skill in COMMON_SKILLS:
        if skill in text:
            found.append(skill)
    return sorted(list(set(found)))

def score_match(resume, job):
    docs = [clean_text(resume), clean_text(job)]
    cv = CountVectorizer()
    matrix = cv.fit_transform(docs)
    score = cosine_similarity(matrix)[0][1] * 100
    return round(score,2)

def suggestions(resume_skills, job_skills):
    missing = [s for s in job_skills if s not in resume_skills]
    tips = []
    if missing:
        tips.append("Add missing skills: " + ", ".join(missing))
    if "experience" not in resume_skills:
        tips.append("Add project or internship experience.")
    tips.append("Use measurable achievements in resume.")
    tips.append("Keep formatting clean and ATS-friendly.")
    return tips

def analyze_resume_text(resume, job):
    rskills = extract_skills(resume)
    jskills = extract_skills(job)
    score = score_match(resume, job)
    tips = suggestions(rskills, jskills)

    return {
        "resume_skills": rskills,
        "job_skills": jskills,
        "score": score,
        "tips": tips
    }